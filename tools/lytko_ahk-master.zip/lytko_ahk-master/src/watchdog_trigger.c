#include <stdio.h>

#include <FreeRTOS.h>
#include <task.h>
#include <timers.h>

#include <esp/gpio.h>

#include "config.h"


static TimerHandle_t watchdog_trigger_timer = NULL;
static TimerHandle_t watchdog_pulse_timer = NULL;


static void watchdog_trigger_timer_callback(TimerHandle_t timer) {
    gpio_write(CONFIG_WATCHDOG_GPIO, 1);
    xTimerStart(watchdog_pulse_timer, 1);
}


static void watchdog_pulse_timer_callback(TimerHandle_t timer) {
    gpio_write(CONFIG_WATCHDOG_GPIO, 0);
}


int watchdog_trigger_start() {
    gpio_write(CONFIG_WATCHDOG_GPIO, 0);
    gpio_enable(CONFIG_WATCHDOG_GPIO, GPIO_OUTPUT);

    watchdog_trigger_timer = xTimerCreate(
        "Watchdog trigger", pdMS_TO_TICKS(CONFIG_WATCHDOG_TRIGGER_PERIOD_MS * 1000),
        pdTRUE, NULL, watchdog_trigger_timer_callback
    );
    if (!watchdog_trigger_timer) {
        printf("Failed to create wifi monitor timer\n");
        return -1;
    }

    watchdog_pulse_timer = xTimerCreate(
        "Watchdog pulse", pdMS_TO_TICKS(10), pdFALSE, NULL,
        watchdog_pulse_timer_callback
    );
    if (!watchdog_pulse_timer) {
        printf("Failed to create wifi monitor timer\n");
        return -1;
    }

    xTimerStart(watchdog_trigger_timer, 1);

    return 0;
}


void watchdog_trigger_stop() {
    if (watchdog_trigger_timer) {
        xTimerStop(watchdog_trigger_timer, 1);
        xTimerDelete(watchdog_trigger_timer, 1);
        watchdog_trigger_timer = NULL;
    }

    if (watchdog_pulse_timer) {
        xTimerStop(watchdog_pulse_timer, 1);
        xTimerDelete(watchdog_pulse_timer, 1);
        watchdog_pulse_timer = NULL;
    }
}
