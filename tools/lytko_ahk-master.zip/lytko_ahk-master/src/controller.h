#pragma once

typedef void controller_t;

#include "controller_private.h"

