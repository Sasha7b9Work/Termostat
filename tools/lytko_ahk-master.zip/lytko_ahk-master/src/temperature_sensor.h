#pragma once

void temperature_sensor_init();
float temperature_sensor_get_temperature();
