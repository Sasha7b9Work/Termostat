#include <string.h>
#include <espressif/esp_common.h>
#include <espressif/esp_wifi.h>
#include <espressif/esp_sta.h>

#include <FreeRTOS.h>
#include <task.h>
#include <timers.h>

#include "config.h"
#include "controller.h"


#define DEBUG(message, ...) printf("wifi monitor: " message "\n", ## __VA_ARGS__)
#define MAX(a, b) ((a) < (b) ? (b) : (a))


static inline uint8_t wifi_rssi_to_level(int8_t rssi) {
    return MAX(0, 4 + (60 + rssi) / 10);
}

static void wifi_scan_callback(void *arg, sdk_scan_status_t status) {
    if (status != SCAN_OK) {
        printf("Scan failed (status %d)\n", status);
        return;
    }

    struct sdk_bss_info *bss = (struct sdk_bss_info *)arg;
    if (!bss) {
        printf("Scan failed: no BSS info\n");
        return;
    }

    // first entry for some reason is invalid
    bss = bss->next.stqe_next;

    while (bss) {
        // above -60 is excelent signal, then reduce 1 level per each 10dBm
        uint8_t level = wifi_rssi_to_level(bss->rssi);
        DEBUG("WiFi \"%s\" signal strength: %d (%d dBm)\n", bss->ssid, level, bss->rssi);

        controller_notify_wifi_signal(level);

        bss = bss->next.stqe_next;
    }
}


static struct sdk_scan_config scan_config = {};
static TimerHandle_t wifi_monitor_timer = NULL;

static void wifi_monitor_timer_callback(TimerHandle_t timer) {
    printf("WiFi monitor: scanning\n");
    sdk_wifi_station_scan(&scan_config, wifi_scan_callback);
}


int wifi_monitor_start(char *ssid, uint32_t period_seconds) {
    if (scan_config.ssid) {
        free(scan_config.ssid);
    }
    scan_config.ssid = (uint8_t*) strdup(ssid);

    if (wifi_monitor_timer)
        return 0;

    wifi_monitor_timer_callback(NULL);

    wifi_monitor_timer = xTimerCreate(
        "WiFi monitor", pdMS_TO_TICKS(period_seconds * 1000), pdTRUE, NULL,
        wifi_monitor_timer_callback
    );

    if (!wifi_monitor_timer) {
        printf("Failed to create wifi monitor timer\n");
        return -1;
    }

    xTimerStart(wifi_monitor_timer, 1);

    return 0;
}

void wifi_monitor_stop() {
    if (!wifi_monitor_timer)
        return;

    xTimerStop(wifi_monitor_timer, 1);
    xTimerDelete(wifi_monitor_timer, 1);
    wifi_monitor_timer = NULL;
}
