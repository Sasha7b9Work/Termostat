#pragma once

int watchdog_trigger_start();
void watchdog_trigger_stop();
