#include <FreeRTOS.h>
#include <task.h>
#include <esp/gpio.h>

#include <ds18b20/ds18b20.h>
#include "config.h"
#include "my_homekit.h"
#include "controller.h"


static float temperature = 0;

void temperature_sensor_task(void *_args) {
    gpio_set_pullup(CONFIG_TEMPERATURE_SENSOR_GPIO, true, true);

    while (1) {
        temperature = ds18b20_read_single(CONFIG_TEMPERATURE_SENSOR_GPIO);
        if (temperature >= 1) {
            printf("Got temperature %.2f\n", temperature);
            my_homekit_set_current_temperature(temperature);
            controller_notify_current_temperature(temperature);
        }

        vTaskDelay(CONFIG_TEMPERATURE_POLL_PERIOD_MS / portTICK_PERIOD_MS);
    }
}


void temperature_sensor_init() {
    if (pdPASS != xTaskCreate(temperature_sensor_task, "Temperature sensor", 512, NULL, 1, NULL)) {
        printf("Failed to start temperature sensor task\n");
    }
}


float temperature_sensor_get_temperature() {
    return temperature;
}
