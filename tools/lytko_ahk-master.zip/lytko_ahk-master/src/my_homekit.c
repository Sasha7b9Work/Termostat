#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include <espressif/esp_system.h>

#include <homekit/homekit.h>
#include <homekit/characteristics.h>

#include "config.h"
#include "controller.h"
#include "my_homekit.h"
#include "temperature_sensor.h"


static bool initialized = false;


static void on_target_temperature(homekit_characteristic_t *ch, homekit_value_t value, void *context);
static void on_target_state(homekit_characteristic_t *ch, homekit_value_t value, void *context);

static homekit_characteristic_t current_temperature = HOMEKIT_CHARACTERISTIC_(CURRENT_TEMPERATURE, 0);
static homekit_characteristic_t target_temperature  = HOMEKIT_CHARACTERISTIC_(
    TARGET_TEMPERATURE, 22,
    .min_value = (float[]){ CONFIG_TARGET_TEMPERATURE_MIN },
    .max_value = (float[]){ CONFIG_TARGET_TEMPERATURE_MAX },
    .callback = HOMEKIT_CHARACTERISTIC_CALLBACK(on_target_temperature),
);
static homekit_characteristic_t current_state = HOMEKIT_CHARACTERISTIC_(CURRENT_HEATING_COOLING_STATE, 0);
static homekit_characteristic_t target_state  = HOMEKIT_CHARACTERISTIC_(
    TARGET_HEATING_COOLING_STATE, 0,
    .callback = HOMEKIT_CHARACTERISTIC_CALLBACK(on_target_state),
    .max_value = (float[]) {1},
    .valid_values = {
        .count = 2,
        .values = (uint8_t[]) { 0, 1, },
    },
);
static homekit_characteristic_t units = HOMEKIT_CHARACTERISTIC_(TEMPERATURE_DISPLAY_UNITS, 0);


static void thermostat_identify(homekit_value_t _value) {
    printf("Thermostat identify\n");
}

static homekit_characteristic_t accessory_name = HOMEKIT_CHARACTERISTIC_(NAME, "Thermostat");

static homekit_accessory_t *accessories[] = {
    HOMEKIT_ACCESSORY(.id=1, .category=homekit_accessory_category_thermostat, .services=(homekit_service_t*[]){
        HOMEKIT_SERVICE(ACCESSORY_INFORMATION, .characteristics=(homekit_characteristic_t*[]){
            &accessory_name,
            HOMEKIT_CHARACTERISTIC(MANUFACTURER, CONFIG_MANUFACTURER),
            HOMEKIT_CHARACTERISTIC(SERIAL_NUMBER, "1"),
            HOMEKIT_CHARACTERISTIC(MODEL, CONFIG_MODEL),
            HOMEKIT_CHARACTERISTIC(FIRMWARE_REVISION, CONFIG_FIRMWARE_REVISION),
            HOMEKIT_CHARACTERISTIC(IDENTIFY, thermostat_identify),
            NULL
        }),
        HOMEKIT_SERVICE(THERMOSTAT, .primary=true, .characteristics=(homekit_characteristic_t*[]) {
            HOMEKIT_CHARACTERISTIC(NAME, "Thermostat"),
            &current_temperature,
            &target_temperature,
            &current_state,
            &target_state,
            &units,
            NULL
        }),
        NULL
    }),
    NULL
};


static void on_target_temperature(homekit_characteristic_t *ch, homekit_value_t value, void *context) {
    controller_notify_target_temperature(value.float_value);
}


static void on_target_state(homekit_characteristic_t *ch, homekit_value_t value, void *context) {
    controller_notify_target_state(value.uint8_value);
}


static void on_homekit_event(homekit_event_t event) {
    if (event == HOMEKIT_EVENT_PAIRING_REMOVED) {
        if (!homekit_is_paired()) {
            printf("Restarting\n");
            sdk_system_restart();
        }
    }
}


static homekit_server_config_t homekit_config = {
    .accessories = accessories,
    .config_number = 2,
    .password = "111-11-111",
    .on_event = on_homekit_event,
    .setupId = "A7QJ",
};


void my_homekit_init(char *name) {
    if (initialized)
        return;

    accessory_name.value = HOMEKIT_STRING(name);
    homekit_server_init(&homekit_config);

    current_temperature.value = HOMEKIT_FLOAT(temperature_sensor_get_temperature());

    char setup_uri[32];
    homekit_get_setup_uri(&homekit_config, setup_uri, sizeof(setup_uri));
    controller_notify_qr_code(setup_uri);

    initialized = true;
}

void my_homekit_set_current_temperature(float temperature) {
    current_temperature.value = HOMEKIT_FLOAT(temperature);
    if (initialized) {
        homekit_characteristic_notify(&current_temperature, current_temperature.value);
    }
}

void my_homekit_set_target_temperature(float temperature) {
    target_temperature.value = HOMEKIT_FLOAT(temperature);
    if (initialized) {
        homekit_characteristic_notify(&target_temperature, target_temperature.value);
    }
}

void my_homekit_set_target_state(uint8_t state) {
    target_state.value = HOMEKIT_UINT8(state);
    if (initialized) {
        homekit_characteristic_notify(&target_state, target_state.value);
    }
}


void my_homekit_set_current_state(uint8_t state) {
    current_state.value = HOMEKIT_UINT8(state);
    if (initialized) {
        homekit_characteristic_notify(&current_state, current_state.value);
    }
}
