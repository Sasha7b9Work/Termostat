#include <espressif/esp_wifi.h>
#include <espressif/esp_sta.h>
#include <espressif/esp_common.h>

#include <esp/uart.h>
#include <esp8266.h>

#include <esplibs/libmain.h>

#include <ota-tftp.h>
#include <wifi_config.h>

#include "config.h"
#include "my_homekit.h"
#include "temperature_sensor.h"
#include "wifi_monitor.h"
#include "heater.h"
#include "watchdog_trigger.h"
#include "controller.h"


char *create_accessory_name() {
    char *name_template = CONFIG_NAME_PREFIX "%02X%02x%02X";

    uint8_t mac[6];
    sdk_wifi_get_macaddr(STATION_IF, mac);

    size_t name_size = snprintf(NULL, 0, name_template, mac[3], mac[4], mac[5]) + 1;
    char *name = malloc(name_size);
    snprintf(name, name_size, name_template, mac[3], mac[4], mac[5]);
    name[name_size - 1] = 0;

    return name;
}


static char *instance_name;

static void notify_ssid(char *ssid) {
    controller_notify_wifi_ssid(ssid);
}

static void notify_ip_address() {
    struct ip_info addresses;
    if (sdk_wifi_get_ip_info(STATION_IF, &addresses)) {
        char ip_addr[16];
        snprintf(ip_addr, sizeof(ip_addr), IPSTR, IP2STR(&addresses.ip));
        controller_notify_ip_address(ip_addr);
    }
}

static void notify_no_ip_address() {
    controller_notify_ip_address("");
}

static void on_wifi_event(wifi_config_event_t event) {
    if (event == WIFI_CONFIG_CONNECTED) {
        char *ssid = NULL;
        wifi_config_get(&ssid, NULL);

        notify_ssid(ssid);
        notify_ip_address();

        my_homekit_init(instance_name);
        wifi_monitor_start(ssid, CONFIG_WIFI_MONITOR_POLL_PERIOD);

        free(ssid);
    } else if (event == WIFI_CONFIG_DISCONNECTED) {
        notify_no_ip_address();
        wifi_monitor_stop();
    }
}

void user_init(void) {
#if CONFIG_THERMOSTAT_DEBUG
    uart_set_baud(0, 115200);
#endif

    ota_tftp_init_server(TFTP_PORT);
    controller_start();

    temperature_sensor_init();

    instance_name = create_accessory_name();
    wifi_config_init2(instance_name, CONFIG_WIFI_AP_PASSWORD, on_wifi_event);
#if !CONFIG_THERMOSTAT_DEBUG
    heater_init();
    watchdog_trigger_start();
#endif
}
