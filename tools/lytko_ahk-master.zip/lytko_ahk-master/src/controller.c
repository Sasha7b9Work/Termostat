#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
#include <event_groups.h>

#include <softuart/softuart.h>

#include "config.h"
#include "my_homekit.h"
#include "temperature_sensor.h"
#include "heater.h"

typedef struct _controller_state controller_t;
#include "controller_private.h"

#define SHUTDOWN_FLAG (1 << 0)

#define ERROR(message, ...) printf("!!! controller: " message "\n", ##__VA_ARGS__)
#define DEBUG(message, ...) printf(">>> controller: " message "\n", ##__VA_ARGS__)

#define MIN(a, b) ((b) < (a) ? (b) : (a))
#define MAX(a, b) ((a) < (b) ? (b) : (a))


typedef enum {
    CONTROLLER_SCREEN_LOGO,
    CONTROLLER_SCREEN_TEMPERATURE,
    CONTROLLER_SCREEN_WIFI,
    CONTROLLER_SCREEN_UPDATE,
} controller_screen_t;

struct _controller_state {
    uint8_t uart_no;

    QueueHandle_t notifications;
    EventGroupHandle_t flags;

    char read_buffer[10];
    uint8_t read_buffer_pos;
    uint8_t marker_count;

    char send_buffer[20];

    controller_screen_t active_screen;

    float current_temperature;
    float target_temperature;
    int target_state;
    int wifi_signal;

    bool hysteresis;

    char *wifi_ssid;
    char *ip_address;
    char *qr_code;
};


controller_t *controller;


static void controller_free(controller_t *controller) {
    if (controller->qr_code)
        free(controller->qr_code);
    if (controller->ip_address)
        free(controller->ip_address);
    if (controller->wifi_ssid)
        free(controller->wifi_ssid);

    vEventGroupDelete(controller->flags);
    vQueueDelete(controller->notifications);

    free(controller);
}


static bool is_controller_shutdown(controller_t *controller) {
    return (bool)(xEventGroupGetBits(controller->flags) & SHUTDOWN_FLAG);
}


static void controller_display(controller_t *controller, char *format, ...) {
    va_list args;
    va_start(args, format);
    size_t size = vsnprintf(NULL, 0, format, args);
    va_end(args);

    char *extra_buffer = NULL;
    char *buffer = controller->send_buffer;

    if (size >= sizeof(controller->send_buffer)) {
        buffer = extra_buffer = malloc(size + 1);
    }

    va_start(args, format);
    size = vsnprintf(buffer, size+1, format, args);
    va_end(args);
    buffer[size] = 0;

    DEBUG("sending command \"%s\"", buffer);
    taskENTER_CRITICAL();
    softuart_puts(controller->uart_no, buffer);
    softuart_put(controller->uart_no, 0xff);
    softuart_put(controller->uart_no, 0xff);
    softuart_put(controller->uart_no, 0xff);
    taskEXIT_CRITICAL();

    if (extra_buffer) {
        free(extra_buffer);
    }
}


static void controller_display_current_temperature(controller_t *controller) {
    controller_display(controller, "degree_big.txt=\"%d\"", (int)controller->current_temperature);
}


static void controller_display_target_temperature(controller_t *controller) {
    controller_display(controller, "degree.txt=\"%d\"", (int)controller->target_temperature);
}


static void controller_display_target_state(controller_t *controller) {
    controller_display(controller, "temp_val.val=%d", controller->target_state);
}


static void controller_display_wifi_signal(controller_t *controller) {
    controller_display(controller, "signal_fill.val=%d", controller->wifi_signal);
}


static void controller_display_wifi_ssid(controller_t *controller) {
    if (controller->wifi_ssid == NULL)
        return;

    controller_display(controller, "wifi_net.txt=\"%s\"", controller->wifi_ssid);
}


static void controller_display_ip_address(controller_t *controller) {
    if (controller->ip_address == NULL)
        return;

    controller_display(controller, "ip_addr.txt=\"%s\"", controller->ip_address);
}


static void controller_display_qr_code(controller_t *controller) {
    if (controller->qr_code == NULL)
        return;

    controller_display(controller, "qr_block.txt=\"%s\"", controller->qr_code);
}


static void controller_refresh_screen(controller_t *controller) {
    switch (controller->active_screen) {
        case CONTROLLER_SCREEN_LOGO:
            break;

        case CONTROLLER_SCREEN_TEMPERATURE: {
            controller_display_current_temperature(controller);
            controller_display_target_temperature(controller);
            controller_display_target_state(controller);
            controller_display_wifi_signal(controller);
            break;
        }

        case CONTROLLER_SCREEN_WIFI: {
            controller_display_wifi_ssid(controller);
            controller_display_ip_address(controller);
            controller_display_qr_code(controller);
            break;
        }

        default:
            ;
    }
}


static void controller_process_command(controller_t *controller) {
    char *cmd = controller->read_buffer;
    uint8_t cmd_size = controller->read_buffer_pos; 

    {
        char *debug_buffer = malloc(64);

        size_t left_chars = 63;
        char *p = debug_buffer;
        for (int i=0; i<controller->read_buffer_pos && left_chars >= 3; i++) {
            size_t size = snprintf(p, left_chars, " %02X", cmd[i]);
            p += size;
            left_chars -= size;
        }
        *p = 0;
        DEBUG("received command \"%s\"", debug_buffer);
        free(debug_buffer);
    }

    while (cmd_size && cmd[0] == 0xD1) {
        cmd++;
        cmd_size--;
    }

    if (!cmd_size)
        return;

    if (cmd[0] == 0x88) {
        controller_display(controller, "temp_val.click=1");
    } else if (cmd[0] == 0x66 && cmd_size == 2) {
        // page change notification
        switch (cmd[1]) {
            case 0:
                controller->active_screen = CONTROLLER_SCREEN_LOGO;
                break;
            case 1:
                controller->active_screen = CONTROLLER_SCREEN_TEMPERATURE;
                break;
            case 2:
                controller->active_screen = CONTROLLER_SCREEN_UPDATE;
                break;
            case 3:
                controller->active_screen = CONTROLLER_SCREEN_WIFI;
                break;
        };
        controller_refresh_screen(controller);
    } else if (cmd[0] == 0x65 && cmd_size == 4) {
        // click notification
        if (cmd[1] == 1 && cmd[2] == 0xD && cmd[3] == 1) {
            controller->target_temperature = \
                MIN(controller->target_temperature + 1, CONFIG_TARGET_TEMPERATURE_MAX);
            controller_display_target_temperature(controller);
            my_homekit_set_target_temperature(controller->target_temperature);
        } else if (cmd[1] == 1 && cmd[2] == 0xE && cmd[3] == 1) {
            controller->target_temperature = \
                MAX(controller->target_temperature - 1, CONFIG_TARGET_TEMPERATURE_MIN);
            controller_display_target_temperature(controller);
            my_homekit_set_target_temperature(controller->target_temperature);
        } else if (cmd[1] == 1 && cmd[2] == 0x11 && cmd[3] == 1) {
            controller->target_state = 1;
            controller_display_target_state(controller);
            my_homekit_set_target_state(controller->target_state);
        } else if (cmd[1] == 1 && cmd[2] == 0x14 && cmd[3] == 1) {
            controller->target_state = 0;
            controller_display_target_state(controller);
            my_homekit_set_target_state(controller->target_state);
        }
    }
}


static void controller_process_serial(controller_t *controller) {
    while (softuart_available(controller->uart_no)) {
        uint8_t c = softuart_read(controller->uart_no);

        if (c == 0xff) {
            if (++controller->marker_count >= 3) {
                if (controller->read_buffer_pos) {
                    controller_process_command(controller);
                }
                // Do not hog processing
                taskYIELD();

                controller->read_buffer_pos = 0;
                controller->marker_count = 0;
            }
        } else {
            if (controller->read_buffer_pos < sizeof(controller->read_buffer)) {
                controller->read_buffer[controller->read_buffer_pos++] = c;
                controller->marker_count = 0;
            }
        }
    }
}


void controller_notify(controller_notification_t *notification) {
    if (!controller)
        return;

    if (xQueueSend(controller->notifications, notification, 100 / portTICK_PERIOD_MS) != pdTRUE) {
        ERROR("Failed to send controller notification");
    }
}


void controller_notify_current_temperature(float temperature) {
    controller_notify((controller_notification_t[]) { {
        .event = CONTROLLER_EVENT_CURRENT_TEMPERATURE_CHANGED,
        .float_value = temperature,
    }});
}


void controller_notify_target_temperature(float temperature) {
    controller_notify((controller_notification_t[]) { {
        .event = CONTROLLER_EVENT_TARGET_TEMPERATURE_CHANGED,
        .float_value = temperature,
    }});
}


void controller_notify_target_state(uint8_t state) {
    controller_notify((controller_notification_t[]) { {
        .event = CONTROLLER_EVENT_TARGET_STATE_CHANGED,
        .int_value = state,
    }});
}


void controller_notify_wifi_signal(int signal) {
    controller_notify((controller_notification_t[]) { {
        .event = CONTROLLER_EVENT_WIFI_SIGNAL_STRENGTH,
        .int_value = signal,
    }});
}


void controller_notify_wifi_ssid(char *ssid) {
    controller_notify((controller_notification_t[]) { {
        .event = CONTROLLER_EVENT_WIFI_SSID,
        .data = strdup(ssid),
    }});
}


void controller_notify_ip_address(char *ip_address) {
    controller_notify((controller_notification_t[]) { {
        .event = CONTROLLER_EVENT_IP_ADDRESS,
        .data = strdup(ip_address),
    }});
}


void controller_notify_qr_code(char *qr_code) {
    controller_notify((controller_notification_t[]) { {
        .event = CONTROLLER_EVENT_QR_CODE,
        .data = strdup(qr_code),
    }});
}


static void controller_update_state(controller_t *controller) {
    if (controller->target_state == MY_HOMEKIT_TARGET_STATE_OFF) {

        controller->hysteresis = false;
        heater_disable();
        my_homekit_set_current_state(MY_HOMEKIT_CURRENT_STATE_OFF);

    } else if (controller->target_state == MY_HOMEKIT_TARGET_STATE_HEAT) {

        float hysteresis_adj = controller->hysteresis ? CONFIG_HEATER_HYSTERESIS : 0;
        if (controller->current_temperature + hysteresis_adj < controller->target_temperature) {
            controller->hysteresis = false;
            heater_enable();
            my_homekit_set_current_state(MY_HOMEKIT_CURRENT_STATE_HEATING);
        } else {
            controller->hysteresis = true;
            heater_disable();
            my_homekit_set_current_state(MY_HOMEKIT_CURRENT_STATE_OFF);
        }
    }
}


static void controller_process_notifications(controller_t *controller) {
    controller_notification_t notification;
    while (xQueueReceive(controller->notifications, &notification, 0) == pdTRUE) {
        switch (notification.event) {
            case CONTROLLER_EVENT_CURRENT_TEMPERATURE_CHANGED:
                controller->current_temperature = notification.float_value;
                controller_display_current_temperature(controller);
                controller_update_state(controller);
                break;

            case CONTROLLER_EVENT_TARGET_TEMPERATURE_CHANGED:
                controller->target_temperature =
                    MIN(CONFIG_TARGET_TEMPERATURE_MAX,
                        MAX(CONFIG_TARGET_TEMPERATURE_MIN,
                            notification.float_value));
                controller->hysteresis = false;
                controller_display_target_temperature(controller);
                controller_update_state(controller);
                break;

            case CONTROLLER_EVENT_TARGET_STATE_CHANGED:
                controller->target_state = MIN(1, MAX(0, notification.int_value));
                controller_display_target_state(controller);
                controller_update_state(controller);
                break;

            case CONTROLLER_EVENT_WIFI_SIGNAL_STRENGTH:
                controller->wifi_signal = notification.int_value;
                controller_display_wifi_signal(controller);
                break;

            case CONTROLLER_EVENT_WIFI_SSID:
                if (controller->wifi_ssid)
                    free(controller->wifi_ssid);
                controller->wifi_ssid = notification.data;
                controller_display_wifi_ssid(controller);
                break;

            case CONTROLLER_EVENT_IP_ADDRESS:
                if (controller->ip_address)
                    free(controller->ip_address);
                controller->ip_address = notification.data;
                controller_display_ip_address(controller);
                break;

            case CONTROLLER_EVENT_QR_CODE:
                if (controller->qr_code)
                    free(controller->qr_code);
                controller->qr_code = notification.data;
                controller_display_qr_code(controller);
                break;
        }
    }
}


static void controller_task(void *param) {
    controller->active_screen = CONTROLLER_SCREEN_TEMPERATURE;
    controller_display(controller, "temp_click.val=1");
    controller_refresh_screen(controller);

    while (!is_controller_shutdown(controller)) {
        controller_process_serial(controller);
        controller_process_notifications(controller);

        vTaskDelay(100 / portTICK_PERIOD_MS);
    }

    softuart_close(controller->uart_no);

    controller_free(controller);
    controller = NULL;

    vTaskDelete(NULL);
}


void controller_start() {
    if (controller)
        return;

    controller_t *c = calloc(1, sizeof(controller_t));
    c->notifications = xQueueCreate(10, sizeof(controller_notification_t));
    if (!c->notifications) {
        ERROR("Failed to allocate controller notifications queue");
        controller_free(c);
        return;
    }
    c->flags = xEventGroupCreate();
    if (!c->flags) {
        ERROR("Failed to allocate controller event group");
        controller_free(c);
        return;
    }
    c->uart_no = 0;
    c->current_temperature = temperature_sensor_get_temperature();
    c->target_temperature = MIN(CONFIG_TARGET_TEMPERATURE_MAX, MAX(CONFIG_TARGET_TEMPERATURE_MIN, c->current_temperature));

    if (!softuart_open(c->uart_no, 9600, CONFIG_DISPLAY_RX_GPIO, CONFIG_DISPLAY_TX_GPIO)) {
        ERROR("Failed to intialize soft UART");
        controller_free(c);
        return;
    }

    controller = c;
    if (xTaskCreate(controller_task, "Display Controller", 512, NULL, 1, NULL) != pdTRUE) {
        ERROR("Failed to start controller task");
        controller_free(c);
        controller = NULL;
        return;
    }
}

void controller_stop() {
    if (!controller)
        return;

    xEventGroupSetBits(controller->flags, SHUTDOWN_FLAG);
}
