#pragma once

int wifi_monitor_start(char *ssid, uint32_t peroid_seconds);
void wifi_monitor_stop();
