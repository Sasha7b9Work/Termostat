#pragma once

typedef enum {
    CONTROLLER_EVENT_CURRENT_TEMPERATURE_CHANGED,
    CONTROLLER_EVENT_TARGET_TEMPERATURE_CHANGED,
    CONTROLLER_EVENT_TARGET_STATE_CHANGED,
    CONTROLLER_EVENT_WIFI_SIGNAL_STRENGTH,
    CONTROLLER_EVENT_WIFI_SSID,
    CONTROLLER_EVENT_IP_ADDRESS,
    CONTROLLER_EVENT_QR_CODE,
} controller_event_t;

typedef struct {
    controller_event_t event;
    union {
        int int_value;
        float float_value;
        char *data;
    };
} controller_notification_t;


void controller_start();
void controller_stop();

void controller_notify(controller_notification_t *notification);

void controller_notify_current_temperature(float temperature);
void controller_notify_target_temperature(float temperature);
void controller_notify_target_state(uint8_t state);
void controller_notify_wifi_signal(int signal);
void controller_notify_wifi_ssid(char *ssid);
void controller_notify_ip_address(char *ip_address);
void controller_notify_qr_code(char *qr_code);

